import { useState, useMemo, useEffect, useRef } from 'react';
import {
  Search,
  Smartphone,
  ChevronLeft,
  ChevronRight,
  Wrench,
  Clock,
  AlertTriangle,
  Copy,
  Cpu,
  History,
  CheckCircle2,
  SlidersHorizontal,
  X,
  User,
  Phone,
  Calendar
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { showToast } from '../components/Toast';
import { formatDate } from '../utils/helpers';
import type { RepairRecord, RepairStatus } from '../types';

interface DeviceAsset {
  serial: string;
  brand: string;
  model: string;
  latest_customer: string;
  latest_phone: string;
  latest_status: RepairStatus;
  last_seen: string;
  repairs: RepairRecord[];
  is_board_level: boolean;
}

type SortField = 'serial' | 'brand' | 'tickets_count' | 'last_seen';
type SortDir = 'asc' | 'desc';

export function DevicesPage() {
  const { state } = useStore();
  
  // UI Controls
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sort, setSort] = useState<{ field: SortField; dir: SortDir }>({ field: 'last_seen', dir: 'desc' });
  const [filterType, setFilterType] = useState<'all' | 'repeat' | 'pcb'>('all');
  
  // Drawer State Control
  const [selectedDevice, setSelectedDevice] = useState<DeviceAsset | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setSearchQuery(searchInput);
      setCurrentPage(1);
    }, 250);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [searchInput]);

  // Dynamic Asset Assembly
  const devices = useMemo<DeviceAsset[]>(() => {
    const registry = new Map<string, RepairRecord[]>();

    for (const repair of state.repairs) {
      const serialKey = repair.serial?.trim() || 'UNKNOWN-SERIAL';
      if (serialKey === 'UNKNOWN-SERIAL' || serialKey === '—') continue;
      
      const existing = registry.get(serialKey) || [];
      existing.push(repair);
      registry.set(serialKey, existing);
    }

    return Array.from(registry.entries()).map(([serial, records]) => {
      const sortedRecords = [...records].sort(
        (a, b) => new Date(b.date_in).getTime() - new Date(a.date_in).getTime()
      );
      
      const latest = sortedRecords[0];
      const pcbKeywords = ['power', 'short', 'ic', 'board', 'circuit', 'micro', 'soldering', 'capacitor', 'mosfet', 'rail', 'bios'];
      const isBoardLevel = sortedRecords.some(r => {
        const textToSearch = `${r.mof} ${r.problem} ${r.technician_notes}`.toLowerCase();
        return pcbKeywords.some(keyword => textToSearch.includes(keyword));
      });

      return {
        serial,
        brand: latest.brand,
        model: latest.model,
        latest_customer: latest.customer_name,
        latest_phone: latest.phone,
        latest_status: latest.status,
        last_seen: latest.date_in,
        repairs: sortedRecords,
        is_board_level: isBoardLevel,
      };
    });
  }, [state.repairs]);

  const filteredData = useMemo(() => {
    let result = [...devices];
    const q = searchQuery.toLowerCase().trim();

    if (q) {
      result = result.filter(
        d =>
          d.serial.toLowerCase().includes(q) ||
          d.brand.toLowerCase().includes(q) ||
          d.model.toLowerCase().includes(q) ||
          d.latest_customer.toLowerCase().includes(q)
      );
    }

    if (filterType === 'repeat') {
      result = result.filter(d => d.repairs.length > 1);
    } else if (filterType === 'pcb') {
      result = result.filter(d => d.is_board_level);
    }

    result.sort((a, b) => {
      let av: any = a[sort.field as keyof DeviceAsset];
      let bv: any = b[sort.field as keyof DeviceAsset];
      if (sort.field === 'tickets_count') {
        av = a.repairs.length;
        bv = b.repairs.length;
      }
      if (typeof av === 'number' && typeof bv === 'number') {
        return sort.dir === 'asc' ? av - bv : bv - av;
      }
      return sort.dir === 'asc' ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });

    return result;
  }, [devices, searchQuery, filterType, sort]);

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedData = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, safePage, pageSize]);

  const handleSort = (field: SortField) => {
    setSort(prev => ({
      field,
      dir: prev.field === field && prev.dir === 'asc' ? 'desc' : 'asc'
    }));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => showToast('success', 'Serial copied to clipboard'));
  };

  const getBadgeStyle = (status: RepairStatus) => {
    switch (status) {
      case 'Completed': return 'bg-green-50 text-green-700 border-green-200';
      case 'In Progress': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Awaiting Parts': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'Ready': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Cancelled': return 'bg-gray-50 text-gray-600 border-gray-200';
      default: return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const openDeviceDetails = (device: DeviceAsset) => {
    setSelectedDevice(device);
    setDrawerOpen(true);
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto animate-fade-in relative">
      {/* Header section */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2.5">
            <Smartphone className="h-6 w-6 text-brand-600" />
            Device Asset Registry
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Centralized hardware logs tracking unique units across multi-ticket lifetimes.
          </p>
        </div>

        <div className="flex items-center gap-1.5 rounded-xl bg-gray-100 p-1 self-start md:self-auto">
          <button
            onClick={() => { setFilterType('all'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${filterType === 'all' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            All Hardware ({devices.length})
          </button>
          <button
            onClick={() => { setFilterType('repeat'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all flex items-center gap-1 ${filterType === 'repeat' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            Repeat Offenses
          </button>
          <button
            onClick={() => { setFilterType('pcb'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all flex items-center gap-1 ${filterType === 'pcb' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <Cpu className="h-3.5 w-3.5 text-brand-500" />
            PCB Component Level
          </button>
        </div>
      </div>

      {/* Control Bar */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search assets by serial, brand, model, or customer..."
            className="w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-700 placeholder-gray-400 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
        </div>
      </div>

      {/* Registry Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead className="bg-gray-50 text-xs font-semibold uppercase text-gray-500 border-b border-gray-200 select-none">
              <tr>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('serial')}>
                  <div className="flex items-center gap-1.5">Hardware Serial <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('brand')}>
                  <div className="flex items-center gap-1.5">Device Description <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 text-gray-500">Latest Owner</th>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100 text-center" onClick={() => handleSort('tickets_count')}>
                  <div className="flex items-center justify-center gap-1.5">Tickets History <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 text-center">Live Status</th>
                <th className="px-5 py-3 cursor-pointer text-right hover:bg-gray-100" onClick={() => handleSort('last_seen')}>
                  <div className="flex items-center justify-end gap-1.5">Last Intake <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-gray-400 font-medium">
                    No monitored device assets match your search parameters.
                  </td>
                </tr>
              ) : (
                paginatedData.map((device) => (
                  <tr 
                    key={device.serial} 
                    className="hover:bg-slate-50 transition-colors cursor-pointer"
                    onClick={() => openDeviceDetails(device)}
                  >
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono bg-gray-100 text-gray-800 rounded px-2 py-0.5 text-xs font-bold border border-gray-200 tracking-wider">
                          {device.serial}
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); copyToClipboard(device.serial); }}
                          className="p-1 text-gray-400 hover:text-brand-600 rounded hover:bg-gray-200 transition-all"
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex flex-col">
                        <span className="text-gray-900 font-semibold">{device.brand} {device.model}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {device.repairs.length > 1 && (
                            <span className="inline-flex items-center gap-0.5 rounded bg-amber-50 border border-amber-200 px-1.5 py-0.2 text-[10px] font-bold text-amber-700">
                              <AlertTriangle className="h-2.5 w-2.5" /> Repeat Offender
                            </span>
                          )}
                          {device.is_board_level && (
                            <span className="inline-flex items-center gap-0.5 rounded bg-brand-50 border border-brand-200 px-1.5 py-0.2 text-[10px] font-bold text-brand-700">
                              <Cpu className="h-2.5 w-2.5" /> PCB Level Repair
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs">
                      <div className="flex flex-col text-gray-700">
                        <span className="font-medium text-gray-900">{device.latest_customer}</span>
                        <span className="text-gray-400 mt-0.5">{device.latest_phone}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-1 text-xs font-bold text-gray-700 border border-gray-200">
                        <History className="h-3 w-3 text-gray-400" /> {device.repairs.length}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${getBadgeStyle(device.latest_status)}`}>
                        {device.latest_status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right font-medium text-gray-600 text-xs">
                      {formatDate(device.last_seen)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Control */}
        <div className="bg-gray-50 border-t border-gray-200 px-5 py-3 flex items-center justify-between text-xs text-gray-500 font-medium select-none">
          <div>
            Showing <span className="text-gray-700 font-bold">{filteredData.length === 0 ? 0 : (safePage - 1) * pageSize + 1}</span> to{' '}
            <span className="text-gray-700 font-bold">{Math.min(safePage * pageSize, filteredData.length)}</span> of{' '}
            <span className="text-gray-700 font-bold">{filteredData.length}</span> registry assets.
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={safePage === 1}
              className="p-1 rounded border border-gray-200 bg-white text-gray-600 shadow-2xs hover:bg-gray-50 disabled:opacity-40 transition"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-gray-600">Page <span className="font-bold text-gray-800">{safePage}</span> of {totalPages}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={safePage === totalPages}
              className="p-1 rounded border border-gray-200 bg-white text-gray-600 shadow-2xs hover:bg-gray-50 disabled:opacity-40 transition"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Device Detail Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 flex justify-end">
          <div
            className="fixed inset-0 bg-gray-900/30 backdrop-blur-sm animate-fade-in"
            onClick={() => setDrawerOpen(false)}
          />
          <aside className={`relative z-50 flex w-full max-w-md flex-col bg-white shadow-2xl border-l border-gray-200 transition-transform duration-300 ease-in-out ${drawerOpen && selectedDevice ? 'translate-x-0' : 'translate-x-full'}`}>
            {selectedDevice && (
              <>
                <div className="h-0.5 w-full bg-gradient-to-r from-brand-500 via-brand-400 to-transparent" />
                {/* Header */}
                <div className="flex items-start justify-between px-6 py-5 border-b border-gray-200">
                  <div>
                    <p className="text-[11px] font-semibold uppercase tracking-widest text-brand-600 mb-0.5">Device Asset</p>
                    <h3 className="text-base font-semibold text-gray-900 leading-tight">{selectedDevice.brand} {selectedDevice.model}</h3>
                    <p className="text-xs font-mono text-gray-400 mt-0.5">{selectedDevice.serial}</p>
                  </div>
                  <button
                    onClick={() => setDrawerOpen(false)}
                    className="ml-4 shrink-0 rounded-lg p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-5 space-y-5">
                  {/* Asset snapshot */}
                  <div className="rounded-lg border border-gray-100 bg-gray-50/50 p-4 space-y-2.5">
                    <div className="flex items-center gap-2.5 text-xs">
                      <User className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                      <span className="font-medium text-gray-900">{selectedDevice.latest_customer}</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-xs text-gray-600">
                      <Phone className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                      <span>{selectedDevice.latest_phone}</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-xs text-gray-600">
                      <Calendar className="h-3.5 w-3.5 shrink-0 text-gray-400" />
                      <span>Last Intake: <span className="font-medium text-gray-800">{formatDate(selectedDevice.last_seen)}</span></span>
                    </div>
                  </div>

                  {/* Timeline */}
                  <div>
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3 flex items-center gap-1.5">
                      <Wrench className="h-3.5 w-3.5" />
                      Service History ({selectedDevice.repairs.length})
                    </h4>
                    <div className="relative border-l-2 border-gray-100 ml-2 space-y-4">
                      {selectedDevice.repairs.map((ticket) => (
                        <div key={ticket.id} className="relative pl-5">
                          <div className="absolute -left-[7px] top-1.5 h-3 w-3 rounded-full bg-white border-2 border-brand-400" />
                          <div className="rounded-lg border border-gray-200 bg-white p-3.5 hover:border-gray-300 transition-colors">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-bold text-brand-700 bg-brand-50 px-2 py-0.5 rounded border border-brand-100">
                                {ticket.repair_id}
                              </span>
                              <span className={`text-xs font-medium rounded-full border px-2 py-0.5 ${getBadgeStyle(ticket.status)}`}>{ticket.status}</span>
                            </div>
                            <div className="text-xs space-y-1.5">
                              <div>
                                <span className="text-gray-400 block font-medium mb-0.5">Problem</span>
                                <span className="text-gray-700">{ticket.problem || '—'}</span>
                              </div>
                              {ticket.technician_notes && (
                                <div className="pt-1">
                                  <span className="text-gray-400 block font-medium mb-0.5">Technician Notes</span>
                                  <p className="text-gray-600 bg-gray-50 p-2 rounded border border-gray-200 italic">
                                    {ticket.technician_notes}
                                  </p>
                                </div>
                              )}
                              <div className="flex items-center gap-1.5 pt-1 text-[11px] text-gray-400 border-t border-gray-100 mt-2">
                                <Clock className="h-3 w-3 shrink-0" />
                                <span>{formatDate(ticket.date_in)}</span>
                                <span>·</span>
                                <span className="font-medium text-gray-600">@{ticket.technician || 'unassigned'}</span>
                                <span className="ml-auto font-semibold text-gray-800">${ticket.price}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}