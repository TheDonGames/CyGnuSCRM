import { useState, useMemo, useEffect, useRef } from 'react';
import {
  Search,
  Users,
  UserCircle,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  Pencil,
  KeyRound,
  ShieldCheck,
  X,
  ArrowUpDown,
  Inbox,
  Wrench,
  CheckCircle2,
  AlertCircle,
  Copy,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { showToast } from '../components/Toast';
import { isUserActive, formatDateTime } from '../utils/helpers';
import type { User, UserRole } from '../types';

// ============================================================
// Types — Profile entities
// ============================================================

type CustomerStatus = 'Active' | 'Suspended';
type StaffStatus = 'Online' | 'Offline' | 'Inactive';
type EntityType = 'customers' | 'staff';

interface CustomerProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  total_tickets: number;
  total_spent: number;
  status: CustomerStatus;
}

interface StaffProfile {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  status: StaffStatus;
  created_at: string;
}

type SortDir = 'asc' | 'desc';

interface SortState {
  field: string;
  dir: SortDir;
}

// ============================================================
// Component
// ============================================================

export function ProfilesPage() {
  const { state, service } = useStore();
  const currentUser = service.getCurrentUser();
  const isAdmin = currentUser?.role.toLowerCase() === 'admin';

  // Entity type toggle
  const [entityType, setEntityType] = useState<EntityType>('customers');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Search (debounced)
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [roleFilter, setRoleFilter] = useState<string>('all');

  // Sorting
  const [sort, setSort] = useState<SortState>({ field: 'name', dir: 'asc' });

  // Action menu (Hoisted)
  const [actionMenuId, setActionMenuId] = useState<string | null>(null);
  const [menuPosition, setMenuPosition] = useState<{ x: number; y: number } | null>(null);

  // Edit modal
  const [editModal, setEditModal] = useState<{ type: EntityType; id: string } | null>(null);

  // Reset credentials modal
  const [resetModal, setResetModal] = useState<{ id: string; username: string } | null>(null);
  const [tempPassword, setTempPassword] = useState('');

  // Role change modal
  const [roleModal, setRoleModal] = useState<{ id: string; username: string; currentRole: UserRole } | null>(null);

  // ============================================================
  // Debounce search input
  // ============================================================

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setSearchQuery(searchInput);
      setCurrentPage(1);
    }, 250);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [searchInput]);

  // Reset filters when switching entity type
  useEffect(() => {
    setStatusFilter('all');
    setRoleFilter('all');
    setCurrentPage(1);
    setSort({ field: entityType === 'customers' ? 'name' : 'username', dir: 'asc' });
  }, [entityType]);

  // ============================================================
  // Build profiles
  // ============================================================

  const customerProfiles = useMemo<CustomerProfile[]>(() => {
    const map = new Map<string, CustomerProfile>();
    for (const r of state.repairs) {
      const key = r.phone_norm || r.phone || r.customer_name;
      const existing = map.get(key);
      if (existing) {
        existing.total_tickets += 1;
        if (r.status === 'Completed') {
          existing.total_spent += r.price;
        }
      } else {
        map.set(key, {
          id: key,
          name: r.customer_name,
          phone: r.phone,
          email: r.email || '—',
          total_tickets: 1,
          total_spent: r.status === 'Completed' ? r.price : 0,
          status: 'Active',
        });
      }
    }
    return Array.from(map.values());
  }, [state.repairs]);

  const staffProfiles = useMemo<StaffProfile[]>(() => {
    return state.users.map((u) => {
      const active = isUserActive(u.last_seen);
      let status: StaffStatus = 'Offline';
      if (active) status = 'Online';
      else if (!u.last_login) status = 'Inactive';
      return {
        id: u.id,
        username: u.username,
        email: '—',
        role: u.role,
        status,
        created_at: u.created_at,
      };
    });
  }, [state.users]);

  // ============================================================
  // Apply search + filters + sort
  // ============================================================

  const filteredData = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    if (entityType === 'customers') {
      let rows = customerProfiles;
      if (q) {
        rows = rows.filter(
          (r) =>
            r.name.toLowerCase().includes(q) ||
            r.phone.includes(q) ||
            r.email.toLowerCase().includes(q)
        );
      }
      if (statusFilter !== 'all') {
        rows = rows.filter((r) => r.status === statusFilter);
      }
      rows = [...rows].sort((a, b) => {
        const av = a[sort.field as keyof CustomerProfile];
        const bv = b[sort.field as keyof CustomerProfile];
        if (typeof av === 'number' && typeof bv === 'number') {
          return sort.dir === 'asc' ? av - bv : bv - av;
        }
        return sort.dir === 'asc'
          ? String(av).localeCompare(String(bv))
          : String(bv).localeCompare(String(av));
      });
      return rows;
    }

    let rows = staffProfiles;
    if (q) {
      rows = rows.filter(
        (r) =>
          r.username.toLowerCase().includes(q) ||
          r.email.toLowerCase().includes(q)
      );
    }
    if (statusFilter !== 'all') {
      rows = rows.filter((r) => r.status === statusFilter);
    }
    if (roleFilter !== 'all') {
      rows = rows.filter((r) => r.role === roleFilter);
    }
    rows = [...rows].sort((a, b) => {
      const av = a[sort.field as keyof StaffProfile];
      const bv = b[sort.field as keyof StaffProfile];
      if (typeof av === 'number' && typeof bv === 'number') {
        return sort.dir === 'asc' ? av - bv : bv - av;
      }
      return sort.dir === 'asc'
        ? String(av).localeCompare(String(bv))
        : String(bv).localeCompare(String(av));
    });
    return rows;
  }, [entityType, customerProfiles, staffProfiles, searchQuery, statusFilter, roleFilter, sort]);

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedData = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, safePage, pageSize]);

  // ============================================================
  // Handlers
  // ============================================================

  const handleSort = (field: string) => {
    setSort((prev) => {
      if (prev.field === field) {
        return { field, dir: prev.dir === 'asc' ? 'desc' : 'asc' };
      }
      return { field, dir: 'asc' };
    });
  };

  const handleOpenEdit = (id: string) => {
    setActionMenuId(null);
    setEditModal({ type: entityType, id });
  };

  const handleAction = (action: 'edit' | 'reset' | 'role', id: string) => {
    setActionMenuId(null);
    setMenuPosition(null);
    if (action === 'edit') {
      setEditModal({ type: entityType, id });
    } else if (action === 'reset' && entityType === 'staff') {
      const user = state.users.find((u) => u.id === id);
      if (user) {
        setTempPassword(generateTempPassword());
        setResetModal({ id, username: user.username });
      }
    } else if (action === 'role' && entityType === 'staff') {
      const user = state.users.find((u) => u.id === id);
      if (user) {
        setRoleModal({ id, username: user.username, currentRole: user.role });
      }
    }
  };

  const handleSaveEdit = (updates: Record<string, string>) => {
    if (!editModal) return;
    if (editModal.type === 'staff') {
      service.updateUser(editModal.id, {
        username: updates.username,
        password: updates.password,
      });
      showToast('success', `Staff profile updated`);
    } else {
      const customer = customerProfiles.find((c) => c.id === editModal.id);
      if (customer) {
        const repairs = state.repairs.filter(
          (r) => (r.phone_norm || r.phone || r.customer_name) === customer.id
        );
        for (const r of repairs) {
          service.updateRepair(r.id, {
            customer_name: updates.name || r.customer_name,
            phone: updates.phone || r.phone,
            email: updates.email || r.email,
          });
        }
        showToast('success', `Customer profile updated across ${repairs.length} records`);
      }
    }
    setEditModal(null);
  };

  const handleConfirmReset = () => {
    if (!resetModal) return;
    service.updateUser(resetModal.id, { password: tempPassword });
    showToast('success', `Password reset for ${resetModal.username}. Temporary password: ${tempPassword}`);
    setResetModal(null);
  };

  const handleConfirmRole = (newRole: UserRole) => {
    if (!roleModal) return;
    if (roleModal.id === currentUser?.id && newRole !== currentUser.role) {
      showToast('error', 'You cannot change your own role');
      return;
    }
    service.updateUser(roleModal.id, { role: newRole });
    showToast('success', `${roleModal.username} role changed to ${newRole}`);
    setRoleModal(null);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => showToast('success', 'Copied to clipboard'));
  };

  const statusOptions =
    entityType === 'customers'
      ? [
          { value: 'all', label: 'All Statuses' },
          { value: 'Active', label: 'Active' },
          { value: 'Suspended', label: 'Suspended' },
        ]
      : [
          { value: 'all', label: 'All Statuses' },
          { value: 'Online', label: 'Online' },
          { value: 'Offline', label: 'Offline' },
          { value: 'Inactive', label: 'Inactive' },
        ];

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Profiles Management</h1>
        <p className="mt-1 text-sm text-gray-500">
          {entityType === 'customers'
            ? `${customerProfiles.length} customer profiles`
            : `${staffProfiles.length} staff accounts · ${staffProfiles.filter((s) => s.status === 'Online').length} online`}
        </p>
      </div>

      <div className="mb-4 flex items-center gap-1 rounded-xl bg-gray-100 p-1 w-fit">
        <button
          onClick={() => setEntityType('customers')}
          className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            entityType === 'customers'
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <UserCircle className="h-4 w-4" /> Customer Database
        </button>
        {isAdmin && (
          <button
            onClick={() => setEntityType('staff')}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all ${
              entityType === 'staff'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Users className="h-4 w-4" /> Staff Accounts
          </button>
        )}
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder={
              entityType === 'customers' ? 'Search by name, phone, or email...' : 'Search by username or email...'
            }
            className="w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-700 placeholder-gray-400 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
          className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 focus:border-brand-400 focus:outline-none"
        >
          {statusOptions.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
        </select>
        {entityType === 'staff' && (
          <select
            value={roleFilter}
            onChange={(e) => { setRoleFilter(e.target.value); setCurrentPage(1); }}
            className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 focus:border-brand-400 focus:outline-none"
          >
            <option value="all">All Roles</option>
            <option value="admin">Admin</option>
            <option value="technician">Technician</option>
          </select>
        )}
        <select
          value={pageSize}
          onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
          className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 focus:border-brand-400 focus:outline-none"
        >
          <option value={10}>10 per page</option>
          <option value={25}>25 per page</option>
          <option value={50}>50 per page</option>
        </select>
      </div>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              {entityType === 'customers' ? (
                <tr>
                  <SortHeader label="Name" field="name" sort={sort} onSort={handleSort} />
                  <SortHeader label="Phone" field="phone" sort={sort} onSort={handleSort} />
                  <SortHeader label="Email" field="email" sort={sort} onSort={handleSort} />
                  <SortHeader label="Tickets" field="total_tickets" sort={sort} onSort={handleSort} align="right" />
                  <SortHeader label="Total Spent" field="total_spent" sort={sort} onSort={handleSort} align="right" />
                  <th className="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-2.5 w-10"></th>
                </tr>
              ) : (
                <tr>
                  <SortHeader label="Username" field="username" sort={sort} onSort={handleSort} />
                  <SortHeader label="Email" field="email" sort={sort} onSort={handleSort} />
                  <SortHeader label="Role" field="role" sort={sort} onSort={handleSort} />
                  <SortHeader label="Status" field="status" sort={sort} onSort={handleSort} />
                  <SortHeader label="Date Created" field="created_at" sort={sort} onSort={handleSort} />
                  <th className="px-4 py-2.5 w-10"></th>
                </tr>
              )}
            </thead>
            <tbody>
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16">
                    <div className="flex flex-col items-center justify-center text-center">
                      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gray-100 text-gray-300 mb-4">
                        <Inbox className="h-8 w-8" />
                      </div>
                      <p className="text-sm font-medium text-gray-700">No profiles found</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedData.map((row, i) => (
                  <tr
                    key={row.id}
                    role="button"
                    tabIndex={0}
                    className={`border-b border-gray-100 transition-colors hover:bg-brand-50/40 animate-slide-up ${
                      i % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'
                    }`}
                    style={{ animationDelay: `${i * 30}ms` }}
                    onClick={(e) => {
                      const target = e.target as HTMLElement;
                      if (target.closest('button')) return;
                      handleOpenEdit(row.id);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        handleOpenEdit(row.id);
                      }
                    }}
                  >
                    {entityType === 'customers' ? (
                      <CustomerRow
                        row={row as CustomerProfile}
                        onMenuToggle={(event) => {
                          if (actionMenuId === row.id) {
                            setActionMenuId(null);
                            setMenuPosition(null);
                            return;
                          }
                          const rect = event.currentTarget.getBoundingClientRect();
                          const menuWidth = 192; // 48 tailwind units
                          const x = Math.max(12, Math.min(window.innerWidth - menuWidth - 12, rect.right - menuWidth));
                          const y = Math.max(12, Math.min(window.innerHeight - 150, rect.bottom + 4));
                          setActionMenuId(row.id);
                          setMenuPosition({ x, y });
                        }}
                      />
                    ) : (
                      <StaffRow
                        row={row as StaffProfile}
                        onMenuToggle={(event) => {
                          if (actionMenuId === row.id) {
                            setActionMenuId(null);
                            setMenuPosition(null);
                            return;
                          }
                          const rect = event.currentTarget.getBoundingClientRect();
                          const menuWidth = 224; // 56 tailwind units
                          const x = Math.max(12, Math.min(window.innerWidth - menuWidth - 12, rect.right - menuWidth));
                          const y = Math.max(12, Math.min(window.innerHeight - 200, rect.bottom + 4));
                          setActionMenuId(row.id);
                          setMenuPosition({ x, y });
                        }}
                      />
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3">
          <p className="text-xs text-gray-500">
            Showing {(safePage - 1) * pageSize + 1}–{Math.min(safePage * pageSize, filteredData.length)} of{' '}
            {filteredData.length} records
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={safePage <= 1}
              className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={safePage >= totalPages}
              className="rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600 disabled:opacity-40 disabled:hover:bg-transparent"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* Global Hoisted Action Menu (Fixes Position Bug) */}
      {/* ============================================================ */}
      {actionMenuId && (
        <>
          <div
            className="fixed inset-0 z-[60]"
            onClick={() => {
              setActionMenuId(null);
              setMenuPosition(null);
            }}
          />
          <div
            className={`fixed z-[70] ${
              entityType === 'staff' ? 'w-56' : 'w-48'
            } rounded-xl border border-gray-200 bg-white py-1.5 shadow-xl animate-fade-in`}
            style={{ top: menuPosition?.y ?? 0, left: menuPosition?.x ?? 0 }}
          >
            <button
              onClick={() => handleAction('edit', actionMenuId)}
              className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <Pencil className="h-4 w-4 text-gray-400" /> Edit Profile Details
            </button>
            {entityType === 'staff' && (
              <>
                <button
                  onClick={() => handleAction('reset', actionMenuId)}
                  className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <KeyRound className="h-4 w-4 text-gray-400" /> Reset Credentials
                </button>
                <div className="my-1.5 border-t border-gray-100" />
                <button
                  onClick={() => handleAction('role', actionMenuId)}
                  className="flex w-full items-center gap-2.5 px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <ShieldCheck className="h-4 w-4 text-gray-400" /> Modify Access Role
                </button>
              </>
            )}
          </div>
        </>
      )}

      {/* ============================================================ */}
      {/* Edit Profile Drawer */}
      {/* ============================================================ */}
      {editModal && (
        <EditProfileDrawer
          modal={editModal}
          customer={editModal.type === 'customers' ? customerProfiles.find((c) => c.id === editModal.id) : null}
          staff={editModal.type === 'staff' ? state.users.find((u) => u.id === editModal.id) : null}
          onSave={handleSaveEdit}
          onClose={() => setEditModal(null)}
        />
      )}

      {/* ============================================================ */}
      {/* Reset Credentials Drawer */}
      {/* ============================================================ */}
      {resetModal && (
        <div className="fixed inset-0 z-[80] flex justify-end">
          <div className="fixed inset-0 bg-gray-900/30 backdrop-blur-sm animate-fade-in" onClick={() => setResetModal(null)} />
          <aside className="relative z-10 flex w-full max-w-md flex-col bg-white shadow-2xl animate-slide-in-right border-l border-gray-200">
            <div className="h-0.5 w-full bg-gradient-to-r from-amber-500 via-amber-400 to-transparent" />
            <div className="flex items-start justify-between px-6 py-5 border-b border-gray-200">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-widest text-amber-600 mb-0.5">Staff Account</p>
                <h2 className="text-lg font-semibold text-gray-900 leading-tight">Reset Credentials</h2>
                <p className="text-xs text-gray-500 mt-0.5">{resetModal.username}</p>
              </div>
              <button onClick={() => setResetModal(null)} className="ml-4 shrink-0 rounded-lg p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 px-6 py-5 space-y-4">
              <div className="flex items-start gap-3 rounded-lg bg-amber-50 border border-amber-200 px-4 py-3">
                <KeyRound className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-sm text-amber-800">Issue a temporary access string for <span className="font-semibold">{resetModal.username}</span>. They must change it on next login.</p>
              </div>
              <div>
                <label className="label">Temporary Password</label>
                <div className="flex gap-2">
                  <input type="text" value={tempPassword} onChange={(e) => setTempPassword(e.target.value)} className="input flex-1 font-mono" />
                  <button onClick={() => copyToClipboard(tempPassword)} className="btn-secondary" title="Copy to clipboard">
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <button onClick={() => setTempPassword(generateTempPassword())} className="text-xs text-brand-600 hover:text-brand-700 font-medium">
                ↻ Generate new random password
              </button>
            </div>
            <div className="flex items-center justify-end gap-3 border-t border-gray-200 px-6 py-4 bg-white">
              <button onClick={() => setResetModal(null)} className="btn-secondary">Cancel</button>
              <button onClick={handleConfirmReset} className="btn-primary">Confirm Reset</button>
            </div>
          </aside>
        </div>
      )}

      {/* ============================================================ */}
      {/* Role Change Drawer */}
      {/* ============================================================ */}
      {roleModal && (
        <div className="fixed inset-0 z-[80] flex justify-end">
          <div className="fixed inset-0 bg-gray-900/30 backdrop-blur-sm animate-fade-in" onClick={() => setRoleModal(null)} />
          <aside className="relative z-10 flex w-full max-w-md flex-col bg-white shadow-2xl animate-slide-in-right border-l border-gray-200">
            <div className="h-0.5 w-full bg-gradient-to-r from-brand-500 via-brand-400 to-transparent" />
            <div className="flex items-start justify-between px-6 py-5 border-b border-gray-200">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-widest text-brand-600 mb-0.5">Access Control</p>
                <h2 className="text-lg font-semibold text-gray-900 leading-tight">Modify Access Role</h2>
                <p className="text-xs text-gray-500 mt-0.5">{roleModal.username}</p>
              </div>
              <button onClick={() => setRoleModal(null)} className="ml-4 shrink-0 rounded-lg p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex-1 px-6 py-5 space-y-4">
              <p className="text-sm text-gray-600">Select a permission level for <span className="font-semibold text-gray-900">{roleModal.username}</span>.</p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleConfirmRole('admin')}
                  className={`flex flex-col items-center gap-2.5 rounded-xl border-2 p-5 transition-all ${roleModal.currentRole === 'admin' ? 'border-brand-400 bg-brand-50' : 'border-gray-200 hover:border-brand-300 hover:bg-gray-50'}`}
                >
                  <ShieldCheck className={`h-7 w-7 ${roleModal.currentRole === 'admin' ? 'text-brand-600' : 'text-gray-400'}`} />
                  <span className="text-sm font-semibold text-gray-900">Admin</span>
                  <span className="text-xs text-gray-500 text-center leading-tight">Full system access</span>
                </button>
                <button
                  onClick={() => handleConfirmRole('technician')}
                  className={`flex flex-col items-center gap-2.5 rounded-xl border-2 p-5 transition-all ${roleModal.currentRole === 'technician' ? 'border-brand-400 bg-brand-50' : 'border-gray-200 hover:border-brand-300 hover:bg-gray-50'}`}
                >
                  <Wrench className={`h-7 w-7 ${roleModal.currentRole === 'technician' ? 'text-brand-600' : 'text-gray-400'}`} />
                  <span className="text-sm font-semibold text-gray-900">Technician</span>
                  <span className="text-xs text-gray-500 text-center leading-tight">Repair workflow access</span>
                </button>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}

// ============================================================
// Cleaned up sub-components
// ============================================================

interface SortHeaderProps {
  label: string;
  field: string;
  sort: SortState;
  onSort: (field: string) => void;
  align?: 'left' | 'right';
}

function SortHeader({ label, field, sort, onSort, align = 'left' }: SortHeaderProps) {
  const isActive = sort.field === field;
  return (
    <th
      className={`px-4 py-2.5 text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer select-none hover:text-gray-700 hover:bg-gray-100 transition-colors ${align === 'right' ? 'text-right' : 'text-left'}`}
      onClick={() => onSort(field)}
    >
      <span className={`inline-flex items-center gap-1 ${align === 'right' ? 'flex-row-reverse' : ''}`}>
        {label}
        {isActive ? sort.dir === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" /> : <ArrowUpDown className="h-3 w-3 text-gray-300" />}
      </span>
    </th>
  );
}

function CustomerRow({ row, onMenuToggle }: { row: CustomerProfile; onMenuToggle: (e: React.MouseEvent<HTMLButtonElement>) => void }) {
  return (
    <>
      <td className="px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-100 text-brand-700 text-xs font-semibold">
            {row.name.charAt(0).toUpperCase()}
          </div>
          <span className="text-sm font-medium text-gray-900 truncate">{row.name}</span>
        </div>
      </td>
      <td className="px-4 py-2.5 text-xs text-gray-600 font-mono">{row.phone}</td>
      <td className="px-4 py-2.5 text-xs text-gray-500">{row.email}</td>
      <td className="px-4 py-2.5 text-sm font-medium text-gray-900 text-right">{row.total_tickets}</td>
      <td className="px-4 py-2.5 text-sm font-semibold text-gray-900 text-right tabular-nums">{row.total_spent.toLocaleString()} LBP</td>
      <td className="px-4 py-2.5"><StatusPill status={row.status} /></td>
      <td className="px-4 py-2.5">
        <button
          type="button"
          onMouseDown={(e) => e.stopPropagation()}
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onMenuToggle(e); }}
          className="rounded-lg p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
        >
          <MoreVertical className="h-4 w-4" />
        </button>
      </td>
    </>
  );
}

function StaffRow({ row, onMenuToggle }: { row: StaffProfile; onMenuToggle: (e: React.MouseEvent<HTMLButtonElement>) => void }) {
  return (
    <>
      <td className="px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          <div className="relative shrink-0">
            <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold ${row.role === 'admin' ? 'bg-brand-100 text-brand-700' : 'bg-gray-100 text-gray-600'}`}>
              {row.username.charAt(0).toUpperCase()}
            </div>
            <span className={`absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full border-2 border-white ${row.status === 'Online' ? 'bg-emerald-500' : row.status === 'Inactive' ? 'bg-red-400' : 'bg-gray-300'}`} />
          </div>
          <span className="text-sm font-medium text-gray-900">{row.username}</span>
        </div>
      </td>
      <td className="px-4 py-2.5 text-xs text-gray-500">{row.email}</td>
      <td className="px-4 py-2.5">
        <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${row.role === 'admin' ? 'bg-brand-50 text-brand-700' : 'bg-gray-100 text-gray-600'}`}>
          {row.role === 'admin' ? <ShieldCheck className="h-3 w-3" /> : <Wrench className="h-3 w-3" />}
          {row.role}
        </span>
      </td>
      <td className="px-4 py-2.5"><StatusPill status={row.status} /></td>
      <td className="px-4 py-2.5 text-xs text-gray-500">{formatDateTime(row.created_at)}</td>
      <td className="px-4 py-2.5">
        <button
          type="button"
          onMouseDown={(e) => e.stopPropagation()}
          onClick={(e) => { e.preventDefault(); e.stopPropagation(); onMenuToggle(e); }}
          className="rounded-lg p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
        >
          <MoreVertical className="h-4 w-4" />
        </button>
      </td>
    </>
  );
}

function StatusPill({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; dot: string; icon?: React.ReactNode }> = {
    Active: { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500', icon: <CheckCircle2 className="h-3 w-3" /> },
    Online: { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500', icon: <CheckCircle2 className="h-3 w-3" /> },
    Suspended: { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500', icon: <AlertCircle className="h-3 w-3" /> },
    Inactive: { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500', icon: <AlertCircle className="h-3 w-3" /> },
    Offline: { bg: 'bg-slate-100', text: 'text-slate-600', dot: 'bg-slate-400' },
  };
  const c = config[status] || { bg: 'bg-gray-100', text: 'text-gray-600', dot: 'bg-gray-400' };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full ${c.bg} ${c.text} px-2.5 py-0.5 text-xs font-medium`}>
      {c.icon || <span className={`h-1.5 w-1.5 rounded-full ${c.dot}`} />}
      {status}
    </span>
  );
}

function EditProfileDrawer({ modal, customer, staff, onSave, onClose }: any) {
  const [form, setForm] = useState<Record<string, string>>(() => {
    if (modal.type === 'customers' && customer) return { name: customer.name, phone: customer.phone, email: customer.email };
    if (modal.type === 'staff' && staff) return { username: staff.username, password: staff.password, email: '' };
    return {};
  });

  useEffect(() => {
    const handler = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const isCustomer = modal.type === 'customers';
  const subtitle = isCustomer ? customer?.name : staff?.username;

  return (
    <div className="fixed inset-0 z-[80] flex justify-end">
      <div className="fixed inset-0 bg-gray-900/30 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <aside className="relative z-10 flex w-full max-w-md flex-col bg-white shadow-2xl animate-slide-in-right border-l border-gray-200">
        <div className="h-0.5 w-full bg-gradient-to-r from-brand-500 via-brand-400 to-transparent" />
        <div className="flex items-start justify-between px-6 py-5 border-b border-gray-200">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-widest text-brand-600 mb-0.5">
              {isCustomer ? 'Customer Profile' : 'Staff Profile'}
            </p>
            <h2 className="text-lg font-semibold text-gray-900 leading-tight">Edit — {subtitle}</h2>
            <p className="text-xs text-gray-500 mt-0.5">Update profile details</p>
          </div>
          <button onClick={onClose} className="ml-4 shrink-0 rounded-lg p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>
        <form id="edit-profile-form" onSubmit={(e) => { e.preventDefault(); onSave(form); }} className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {isCustomer ? (
            <>
              <div><label className="label">Full Name</label><input className="input" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus required /></div>
              <div><label className="label">Phone</label><input className="input" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div><label className="label">Email</label><input className="input" type="email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            </>
          ) : (
            <>
              <div><label className="label">Username</label><input className="input" value={form.username || ''} onChange={(e) => setForm({ ...form, username: e.target.value })} autoFocus required /></div>
              <div><label className="label">Password</label><input className="input font-mono" value={form.password || ''} onChange={(e) => setForm({ ...form, password: e.target.value })} required /></div>
            </>
          )}
        </form>
        <div className="flex items-center justify-end gap-3 border-t border-gray-200 px-6 py-4 bg-white">
          <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
          <button type="submit" form="edit-profile-form" className="btn-primary">Save Changes</button>
        </div>
      </aside>
    </div>
  );
}

function generateTempPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let result = '';
  for (let i = 0; i < 10; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return `Temp${result}`;
}