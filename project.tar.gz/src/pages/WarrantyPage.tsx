import { useState, useMemo, useRef, useEffect } from 'react';
import {
  ShieldCheck,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  X,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  Smartphone,
  User,
  Calendar,
  History,
  Timer,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { showToast } from '../components/Toast';
import { formatDate } from '../utils/helpers';
import type { RepairRecord } from '../types';

// Standard baseline warranty configuration for board-level or component fixes
const DEFAULT_WARRANTY_DAYS = 90;

interface WarrantyAsset {
  id: string;
  repairId: string;
  customerName: string;
  phone: string;
  deviceDescription: string;
  serial: string;
  deliveryDate: string;
  expiryDate: string;
  daysRemaining: number;
  status: 'Active' | 'Expired' | 'Claim Window';
  isClaimed: boolean; // Flagged if a subsequent ticket exists for the same hardware
  rawRecord: RepairRecord;
}

type SortField = 'expiryDate' | 'customerName' | 'daysRemaining' | 'repairId';
type SortDir = 'asc' | 'desc';

export function WarrantyPage() {
  const { state } = useStore();

  // Component UI State
  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Expired' | 'Claims'>('All');
  const [sort, setSort] = useState<{ field: SortField; dir: SortDir }>({ field: 'expiryDate', dir: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Drawer Controls
  const [selectedWarranty, setSelectedWarranty] = useState<WarrantyAsset | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setSearchQuery(searchInput);
      setCurrentPage(1);
    }, 250);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [searchInput]);

  // Dynamically compile warranty life-cycles from state records
  const warranties = useMemo<WarrantyAsset[]>(() => {
    const records = state.repairs;
    const now = new Date();

    return records
      .filter((r) => r.status === 'Completed' || r.status === 'Ready' || r.date_out)
      .map((repair) => {
        // Base calculation on departure date, fall back to intake date if missing
        const startTimestamp = repair.date_out || repair.date_in;
        const startDate = new Date(startTimestamp);
        
        const expiryDate = new Date(startDate);
        expiryDate.setDate(startDate.getDate() + DEFAULT_WARRANTY_DAYS);

        const timeDiff = expiryDate.getTime() - now.getTime();
        const daysRemaining = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

        // Auto-detect claims: check if the same serial number checked back in later
        const subsequentTickets = records.filter(
          (r) => 
            r.serial === repair.serial && 
            r.serial !== '—' && 
            new Date(r.date_in).getTime() > new Date(repair.date_in).getTime()
        );
        const isClaimed = subsequentTickets.length > 0;

        let status: 'Active' | 'Expired' | 'Claim Window' = 'Active';
        if (isClaimed) {
          status = 'Claim Window';
        } else if (daysRemaining <= 0) {
          status = 'Expired';
        }

        return {
          id: repair.id,
          repairId: repair.repair_id || `REP-${repair.id.substring(0, 4)}`,
          customerName: repair.customer_name,
          phone: repair.phone,
          deviceDescription: `${repair.brand} ${repair.model}`,
          serial: repair.serial || '—',
          deliveryDate: startTimestamp,
          expiryDate: expiryDate.toISOString(),
          daysRemaining: daysRemaining > 0 ? daysRemaining : 0,
          status,
          isClaimed,
          rawRecord: repair
        };
      });
  }, [state.repairs]);

  // Metric aggregates calculations
  const metrics = useMemo(() => {
    let active = 0;
    let expired = 0;
    let claims = 0;

    warranties.forEach((w) => {
      if (w.status === 'Active') active++;
      if (w.status === 'Expired') expired++;
      if (w.status === 'Claim Window') claims++;
    });

    return { active, expired, claims, total: warranties.length };
  }, [warranties]);

  // Filter & Sort Application Process
  const filteredData = useMemo(() => {
    let result = [...warranties];
    const q = searchQuery.toLowerCase().trim();

    if (q) {
      result = result.filter(
        w =>
          w.repairId.toLowerCase().includes(q) ||
          w.customerName.toLowerCase().includes(q) ||
          w.deviceDescription.toLowerCase().includes(q) ||
          w.serial.toLowerCase().includes(q)
      );
    }

    if (statusFilter === 'Active') result = result.filter((w) => w.status === 'Active');
    if (statusFilter === 'Expired') result = result.filter((w) => w.status === 'Expired');
    if (statusFilter === 'Claims') result = result.filter((w) => w.status === 'Claim Window');

    result.sort((a, b) => {
      let av = a[sort.field];
      let bv = b[sort.field];

      if (sort.field === 'daysRemaining') {
        return sort.dir === 'asc' ? (av as number) - (bv as number) : (bv as number) - (av as number);
      }

      return sort.dir === 'asc'
        ? String(av).localeCompare(String(bv))
        : String(bv).localeCompare(String(av));
    });

    return result;
  }, [warranties, searchQuery, statusFilter, sort]);

  // Pagination Engine
  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedData = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, safePage, pageSize]);

  const handleSort = (field: SortField) => {
    setSort((prev) => ({
      field,
      dir: prev.field === field && prev.dir === 'asc' ? 'desc' : 'asc'
    }));
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto animate-fade-in">
      {/* Top Section Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2.5">
            <ShieldCheck className="h-6 w-6 text-brand-600" />
            Warranty Status Control
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Monitor active post-repair guarantees, calculate track timelines, and supervise return claims.
          </p>
        </div>

        {/* Quick Lifecycle Filters */}
        <div className="flex items-center gap-1.5 rounded-xl bg-gray-100 p-1 self-start md:self-auto">
          <button
            onClick={() => { setStatusFilter('All'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${statusFilter === 'All' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            All Coverage ({metrics.total})
          </button>
          <button
            onClick={() => { setStatusFilter('Active'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all flex items-center gap-1 ${statusFilter === 'Active' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
            Active ({metrics.active})
          </button>
          <button
            onClick={() => { setStatusFilter('Claims'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all flex items-center gap-1 ${statusFilter === 'Claims' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            Claims Raised ({metrics.claims})
          </button>
          <button
            onClick={() => { setStatusFilter('Expired'); setCurrentPage(1); }}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${statusFilter === 'Expired' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
          >
            Expired ({metrics.expired})
          </button>
        </div>
      </div>

      {/* Overview Analytics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-2xs flex items-center gap-4">
          <div className="p-3 bg-emerald-50 rounded-lg text-emerald-600"><CheckCircle2 className="h-5 w-5" /></div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Active Guard Assays</p>
            <p className="text-xl font-black text-gray-900">{metrics.active} Items</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-2xs flex items-center gap-4">
          <div className="p-3 bg-amber-50 rounded-lg text-amber-600"><AlertTriangle className="h-5 w-5" /></div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Return Loss Rate</p>
            <p className="text-xl font-black text-gray-900">
              {metrics.total > 0 ? ((metrics.claims / metrics.total) * 100).toFixed(1) : 0}%
            </p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-2xs flex items-center gap-4">
          <div className="p-3 bg-slate-50 rounded-lg text-slate-500"><Timer className="h-5 w-5" /></div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Standard Window Duration</p>
            <p className="text-xl font-black text-gray-900">{DEFAULT_WARRANTY_DAYS} Days</p>
          </div>
        </div>
      </div>

      {/* Control Search Utility Bar */}
      <div className="mb-4 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Filter protected inventory assets via job id, customer signature, or hardware index..."
            className="w-full rounded-lg border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-700 placeholder-gray-400 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
        </div>
      </div>

      {/* Data Table */}
      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-sm">
            <thead className="bg-gray-50 text-xs font-semibold uppercase text-gray-500 border-b border-gray-200 select-none">
              <tr>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('repairId')}>
                  <div className="flex items-center gap-1.5">Origin Job <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('customerName')}>
                  <div className="flex items-center gap-1.5">Billed Holder <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 text-gray-500">Hardware Profile</th>
                <th className="px-5 py-3 cursor-pointer hover:bg-gray-100 text-center" onClick={() => handleSort('expiryDate')}>
                  <div className="flex items-center justify-center gap-1.5">Coverage Expiration <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 cursor-pointer text-center hover:bg-gray-100" onClick={() => handleSort('daysRemaining')}>
                  <div className="flex items-center justify-center gap-1.5">Timeline Delta <SlidersHorizontal className="h-3 w-3 text-gray-400" /></div>
                </th>
                <th className="px-5 py-3 text-center">Status Badge</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-gray-400 font-medium">
                    No active or registered item guarantees correspond with chosen filter variables.
                  </td>
                </tr>
              ) : (
                paginatedData.map((w) => (
                  <tr
                    key={w.id}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    onClick={() => { setSelectedWarranty(w); setDrawerOpen(true); }}
                  >
                    <td className="px-5 py-3.5">
                      <span className="font-mono bg-slate-100 text-gray-900 rounded px-2 py-0.5 text-xs font-bold border border-gray-200 group-hover:text-brand-600 transition">
                        {w.repairId}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex flex-col text-xs">
                        <span className="font-bold text-gray-900">{w.customerName}</span>
                        <span className="text-gray-400 mt-0.5">{w.phone}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-xs">
                      <div className="flex flex-col">
                        <span className="font-semibold text-gray-800">{w.deviceDescription}</span>
                        <span className="text-[11px] font-mono text-gray-400 mt-0.5">SN: {w.serial}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-center text-xs font-medium text-gray-600">
                      {formatDate(w.expiryDate)}
                    </td>
                    <td className="px-5 py-3.5 text-center font-bold text-gray-900 text-xs">
                      {w.status === 'Expired' ? (
                        <span className="text-gray-400">—</span>
                      ) : (
                        <span className="flex items-center justify-center gap-1 text-slate-700">
                          <Clock className="h-3 w-3 text-gray-400" /> {w.daysRemaining} days left
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold ${
                        w.status === 'Active' ? 'bg-green-50 text-green-700 border-green-200' :
                        w.status === 'Claim Window' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                        'bg-gray-50 text-gray-500 border-gray-200'
                      }`}>
                        {w.status === 'Claim Window' && <AlertCircle className="h-3 w-3" />}
                        {w.status === 'Claim Window' ? 'Claim Filed' : w.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Standard Control Block */}
        <div className="bg-gray-50 border-t border-gray-200 px-5 py-3 flex items-center justify-between text-xs text-gray-500 font-medium select-none">
          <div>
            Showing <span className="text-gray-700 font-bold">{filteredData.length === 0 ? 0 : (safePage - 1) * pageSize + 1}</span> to{' '}
            <span className="text-gray-700 font-bold">{Math.min(safePage * pageSize, filteredData.length)}</span> of{' '}
            <span className="text-gray-700 font-bold">{filteredData.length}</span> registry records.
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={safePage === 1}
              className="p-1 rounded border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-40 transition"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-gray-600">Page <span className="font-bold text-gray-800">{safePage}</span> of {totalPages}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={safePage === totalPages}
              className="p-1 rounded border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-40 transition"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Drawer Overlay Backdrop */}
      {drawerOpen && (
        <div className="fixed inset-0 bg-black/30 z-40 transition-opacity animate-fade-in" onClick={() => setDrawerOpen(false)} />
      )}

      {/* Right Drawer Panel Canvas */}
      <div className={`fixed inset-y-0 right-0 w-full max-w-md bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out border-l border-gray-200 flex flex-col ${
        drawerOpen && selectedWarranty ? 'translate-x-0' : 'translate-x-full'
      }`}>
        {selectedWarranty && (
          <>
            {/* Header */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-brand-600" />
                <div>
                  <h3 className="text-sm font-bold text-gray-900">Warranty Audit Checklist</h3>
                  <p className="text-xs text-gray-400 mt-0.5">Asset Reference: {selectedWarranty.repairId}</p>
                </div>
              </div>
              <button onClick={() => setDrawerOpen(false)} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-200 transition">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {/* Hardware Profile Snapshot */}
              <div className="border border-gray-200 bg-slate-50/50 rounded-xl p-4 space-y-3">
                <div className="flex items-start gap-2.5">
                  <Smartphone className="h-4 w-4 text-gray-400 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-bold text-gray-900 block">{selectedWarranty.deviceDescription}</span>
                    <span className="font-mono text-gray-500 mt-0.5 block">Serial: {selectedWarranty.serial}</span>
                  </div>
                </div>
                <div className="border-t border-gray-200/60 pt-2.5 flex items-start gap-2.5">
                  <User className="h-4 w-4 text-gray-400 mt-0.5" />
                  <div className="text-xs">
                    <span className="font-semibold text-gray-900 block">{selectedWarranty.customerName}</span>
                    <span className="text-gray-500 mt-0.5 block">{selectedWarranty.phone}</span>
                  </div>
                </div>
              </div>

              {/* Warranty Timeline Timeline Tracker */}
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-gray-400" />
                  Protection Timeline Logs
                </h4>
                <div className="relative border-l-2 border-slate-100 ml-2 space-y-4">
                  <div className="relative pl-5">
                    <div className="absolute -left-[5px] top-1 h-2 w-2 rounded-full bg-emerald-500" />
                    <div className="text-xs">
                      <span className="font-bold text-gray-900">Job Delivered / Dispatched</span>
                      <p className="text-gray-400 mt-0.5">{formatDate(selectedWarranty.deliveryDate)}</p>
                    </div>
                  </div>

                  <div className="relative pl-5">
                    <div className={`absolute -left-[5px] top-1 h-2 w-2 rounded-full ${selectedWarranty.status === 'Expired' ? 'bg-gray-400' : 'bg-brand-500'}`} />
                    <div className="text-xs">
                      <span className="font-bold text-gray-900">Calculated Expiration Point</span>
                      <p className="text-gray-400 mt-0.5">{formatDate(selectedWarranty.expiryDate)}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Claims Diagnostic Conditions Context */}
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <History className="h-3.5 w-3.5 text-gray-400" />
                  Historical Service Origin
                </h4>
                <div className="bg-white border border-gray-100 rounded-xl p-3.5 space-y-2 text-xs shadow-2xs">
                  <div>
                    <span className="text-gray-400 block font-medium">Addressed Component Failure</span>
                    <span className="text-gray-800 font-medium">{selectedWarranty.rawRecord.problem || '—'}</span>
                  </div>
                  {selectedWarranty.rawRecord.technician_notes && (
                    <div className="pt-1.5 border-t border-gray-50">
                      <span className="text-gray-400 block font-medium">Technician Repair Manifest Summary</span>
                      <p className="text-gray-600 italic bg-slate-50 p-2.5 rounded border border-dashed border-gray-200 mt-1">
                        {selectedWarranty.rawRecord.technician_notes}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Status Conditional Infobox Notification */}
              {selectedWarranty.status === 'Claim Window' && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3 text-xs text-amber-800 leading-relaxed">
                  <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-amber-900">Linked Return Claim Discovered</span>
                    This specific device assembly has returned to the workshop configuration on a subsequent repair ticket. Cross-reference internal parts manifests to confirm if active components are eligible for coverage.
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}