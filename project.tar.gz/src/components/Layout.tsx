import { useState, useEffect, type ReactNode } from 'react';
import {
  LayoutDashboard,
  Wrench,
  Users,
  UserCircle,
  Smartphone,
  FileText,
  ShieldCheck,
  Boxes,
  MessageCircle,
  Bell,
  Send,
  ScrollText,
  Activity,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  Lock,
  CircleDot,
  Clock,
  Database,
  Printer,
  ScanLine,
  Receipt,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { isUserActive, formatTimeAgo } from '../utils/helpers';
import { showToast } from './Toast';
import { DocumentPreviewModal, type PreviewType } from './DocumentPreviewModal';
import type { RepairRecord } from '../types';

// ============================================================
// Page keys — all navigable views in the application
// ============================================================

export type PageKey =
  | 'dashboard'
  | 'repairs'
  | 'customers'
  | 'devices'
  | 'invoices'
  | 'warranty'
  | 'inventory'
  | 'whatsapp'
  | 'rules'
  | 'notifications'
  | 'users'
  | 'logs'
  | 'activity'
  | 'settings';

// ============================================================
// Navigation taxonomy — categorized per menubar.py
// ============================================================

interface NavItem {
  key: PageKey;
  label: string;
  icon: ReactNode;
  adminOnly?: boolean;
  badge?: 'queued';
}

interface NavCategory {
  label: string;
  items: NavItem[];
}

const NAV_CATEGORIES: NavCategory[] = [
  {
    label: 'Workspace',
    items: [
      { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
      { key: 'repairs', label: 'Repairs / Tickets', icon: <Wrench className="h-5 w-5" /> },
      { key: 'customers', label: 'Customer Profiles', icon: <UserCircle className="h-5 w-5" /> },
      { key: 'devices', label: 'Devices', icon: <Smartphone className="h-5 w-5" /> },
    ],
  },
  {
    label: 'Logistics & Finance',
    items: [
      { key: 'invoices', label: 'Invoices Hub', icon: <FileText className="h-5 w-5" /> },
      { key: 'warranty', label: 'Warranty Status', icon: <ShieldCheck className="h-5 w-5" /> },
      { key: 'inventory', label: 'Inventory / Stock', icon: <Boxes className="h-5 w-5" /> },
    ],
  },
  {
    label: 'Communications',
    items: [
      { key: 'whatsapp', label: 'WhatsApp Integration', icon: <MessageCircle className="h-5 w-5" /> },
      { key: 'rules', label: 'Auto-Notify Rules', icon: <Bell className="h-5 w-5" />, adminOnly: true },
      { key: 'notifications', label: 'Outbox Log', icon: <Send className="h-5 w-5" />, badge: 'queued' },
    ],
  },
  {
    label: 'Administrative',
    items: [
      { key: 'users', label: 'Users Management', icon: <Users className="h-5 w-5" />, adminOnly: true },
      { key: 'logs', label: 'Central Audit Trail', icon: <ScrollText className="h-5 w-5" />, adminOnly: true },
      { key: 'activity', label: 'System Activity Log', icon: <Activity className="h-5 w-5" />, adminOnly: true },
      { key: 'settings', label: 'System Settings', icon: <Settings className="h-5 w-5" />, adminOnly: true },
    ],
  },
];

// ============================================================
// Layout component
// ============================================================

interface LayoutProps {
  currentPage: PageKey;
  onNavigate: (page: PageKey) => void;
  children: ReactNode;
}

export function Layout({ currentPage, onNavigate, children }: LayoutProps) {
  const { state, service } = useStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [clock, setClock] = useState(new Date());
  const [refreshing, setRefreshing] = useState(false);
  const [previewType, setPreviewType] = useState<PreviewType | null>(null);

  const user = service.getCurrentUser();

  // Live clock — updates every second
  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!user) return null;

  const normalizedRole = user.role.toLowerCase();
  const activeUsers = state.users.filter((u) => isUserActive(u.last_seen));
  const queuedCount = state.notifications.filter((n) => n.status === 'queued').length;
  const previewRepair: RepairRecord | null = state.repairs[0] || null;

  const handleLogout = () => {
    service.logout();
  };

  const handleRefresh = () => {
    setRefreshing(true);
    service.heartbeat();
    setTimeout(() => {
      setRefreshing(false);
      showToast('success', 'System data refreshed');
    }, 600);
  };

  const handleNavigate = (page: PageKey) => {
    onNavigate(page);
    setSidebarOpen(false);
  };

  // Filter categories by role
  const visibleCategories = NAV_CATEGORIES.map((cat) => ({
    ...cat,
    items: cat.items.filter((item) => !item.adminOnly || normalizedRole === 'admin'),
  })).filter((cat) => cat.items.length > 0);

  // ============================================================
  // Sidebar content (shared between desktop + mobile)
  // ============================================================

  const renderNavItem = (item: NavItem) => {
    const active = currentPage === item.key;
    const showLabel = !collapsed;
    return (
      <div key={item.key} className="relative group">
        <button
          onClick={() => handleNavigate(item.key)}
          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
            active
              ? 'bg-brand-50 text-brand-700'
              : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
          } ${collapsed ? 'justify-center' : ''}`}
        >
          <span className={active ? 'text-brand-600' : 'text-gray-400'}>{item.icon}</span>
          {showLabel && (
            <>
              <span className="flex-1 text-left truncate">{item.label}</span>
              {item.badge === 'queued' && queuedCount > 0 && (
                <span className="ml-auto rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700">
                  {queuedCount}
                </span>
              )}
            </>
          )}
        </button>
        {/* Tooltip when collapsed */}
        {collapsed && (
          <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 z-50 hidden group-hover:block">
            <div className="whitespace-nowrap rounded-md bg-gray-900 px-2.5 py-1.5 text-xs font-medium text-white shadow-lg">
              {item.label}
              {item.badge === 'queued' && queuedCount > 0 && (
                <span className="ml-1.5 text-amber-300">({queuedCount})</span>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderNavContent = (isMobile = false) => (
    <>
      {/* Brand header */}
      <div className={`flex items-center gap-3 border-b border-gray-200 ${collapsed && !isMobile ? 'justify-center px-3 py-4' : 'px-5 py-4'}`}>
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white shadow-md shrink-0">
          <ShieldCheck className="h-6 w-6" />
        </div>
        {(!collapsed || isMobile) && (
          <div>
            <h1 className="text-lg font-bold text-gray-900 leading-tight">CyGnuS SARL</h1>
            <p className="text-xs text-gray-500">CRM Pro Repair</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-3 overflow-y-auto">
        {visibleCategories.map((cat, idx) => (
          <div key={cat.label} className={idx > 0 ? 'mt-5' : ''}>
            {(!collapsed || isMobile) && (
              <p className="px-3 mb-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                {cat.label}
              </p>
            )}
            {collapsed && !isMobile && idx > 0 && <div className="mx-3 my-3 border-t border-gray-100" />}
            <div className="space-y-0.5">
              {cat.items.map(renderNavItem)}
            </div>
          </div>
        ))}
      </nav>

      {/* Active users widget */}
      {(!collapsed || isMobile) && (
        <div className="px-3 pt-2 pb-3">
          <div className="rounded-lg border border-gray-100 bg-gray-50/50 p-3">
            <div className="mb-2.5 flex items-center gap-2">
              <CircleDot className="h-3.5 w-3.5 shrink-0 text-emerald-500 animate-pulse-soft" />
              <span className="text-[11px] font-semibold uppercase tracking-wide text-gray-500">
                {activeUsers.length} Active Now
              </span>
            </div>
            <div className="space-y-1.5">
              {state.users.slice(0, 3).map((u) => (
                <div key={u.id} className="flex items-center gap-2 text-xs">
                  <span
                    className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                      isUserActive(u.last_seen) ? 'bg-emerald-500' : 'bg-gray-300'
                    }`}
                  />
                  <span className="truncate font-medium text-gray-700">{u.username}</span>
                  <span className="ml-auto shrink-0 text-gray-400">{formatTimeAgo(u.last_seen)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* User profile footer */}
      <div className={`border-t border-gray-200 p-3 ${collapsed && !isMobile ? 'flex justify-center' : ''}`}>
        <div className={`flex items-center gap-3 rounded-lg ${collapsed && !isMobile ? 'justify-center p-2' : 'px-2 py-1.5'}`}>
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-brand-700 font-semibold text-sm shrink-0">
            {user.username.charAt(0).toUpperCase()}
          </div>
          {(!collapsed || isMobile) && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user.username}</p>
              <p className="text-xs text-gray-500 capitalize">{normalizedRole}</p>
            </div>
          )}
          {(!collapsed || isMobile) && (
            <button
              onClick={handleLogout}
              className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-red-50 hover:text-red-600"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </>
  );

  // ============================================================
  // Desktop collapse toggle button
  // ============================================================

  const collapseButton = (
    <button
      onClick={() => setCollapsed(!collapsed)}
      className="absolute -right-3 top-20 z-30 flex h-6 w-6 items-center justify-center rounded-full border border-gray-200 bg-white text-gray-400 shadow-sm transition-all hover:text-brand-600 hover:shadow-md"
      title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
    >
      {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
    </button>
  );

  // ============================================================
  // Global header (desktop)
  // ============================================================

  const desktopHeader = (
    <header className="hidden lg:flex items-center justify-between border-b border-gray-200 bg-white px-6 py-3">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Printer className="h-4 w-4 text-gray-300" />
          <span className="text-xs text-gray-400">Print Preview:</span>
          <button
            onClick={() => setPreviewType('invoice')}
            className="text-xs text-brand-600 hover:text-brand-700 hover:underline"
            title="Invoice Preview"
          >
            Invoice
          </button>
          <span className="text-gray-200">·</span>
          <button
            onClick={() => setPreviewType('receipt')}
            className="text-xs text-brand-600 hover:text-brand-700 hover:underline"
            title="Receipt Preview"
          >
            Receipt
          </button>
          <span className="text-gray-200">·</span>
          <button
            onClick={() => setPreviewType('barcode')}
            className="text-xs text-brand-600 hover:text-brand-700 hover:underline"
            title="Barcode/Label Preview"
          >
            <ScanLine className="h-3 w-3 inline mr-0.5" />Label
          </button>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Refresh button */}
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 transition-colors hover:bg-gray-50 hover:text-gray-900"
          title="Refresh System Data"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>

        {/* User profile area */}
        <div className="flex items-center gap-2.5 pl-3 border-l border-gray-200">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-brand-700 font-semibold text-xs">
            {user.username.charAt(0).toUpperCase()}
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900 leading-tight">{user.username}</p>
            <span className="text-[10px] font-bold text-brand-600 uppercase tracking-wider">{normalizedRole}</span>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-2.5 py-1.5 text-xs font-medium text-gray-600 transition-colors hover:bg-red-50 hover:text-red-600 hover:border-red-200"
            title="Lock / Switch User"
          >
            <Lock className="h-3.5 w-3.5" />
            Lock
          </button>
        </div>
      </div>
    </header>
  );

  // ============================================================
  // Mobile header
  // ============================================================

  const mobileHeader = (
    <header className="lg:hidden flex items-center justify-between border-b border-gray-200 bg-white px-4 py-3">
      <button
        onClick={() => setSidebarOpen(true)}
        className="rounded-lg p-2 text-gray-600 hover:bg-gray-100"
      >
        <Menu className="h-5 w-5" />
      </button>
      <div className="flex items-center gap-2">
        <ShieldCheck className="h-5 w-5 text-brand-600" />
        <span className="font-semibold text-gray-900">CyGnuS SARL</span>
      </div>
      <button
        onClick={handleRefresh}
        className="rounded-lg p-2 text-gray-600 hover:bg-gray-100"
        title="Refresh"
      >
        <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
      </button>
    </header>
  );

  // ============================================================
  // Status footer bar
  // ============================================================

  const statusFooter = (
    <footer className="hidden lg:flex items-center justify-between border-t border-gray-200 bg-white px-6 py-1.5 text-xs text-gray-500">
      {/* Left: logged in as */}
      <div className="flex items-center gap-2">
        <CircleDot className="h-3 w-3 text-emerald-500" />
        <span>
          Logged in as: <span className="font-medium text-gray-700">{user.username}</span>{' '}
          (<span className="font-medium text-gray-700 capitalize">{normalizedRole}</span>)
        </span>
      </div>

      {/* Center: database status */}
      <div className="flex items-center gap-2">
        <Database className="h-3 w-3 text-gray-400" />
        <span>Database Status: Connected to 192.168.1.9</span>
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
        </span>
        <span className="font-medium text-emerald-600">Active</span>
      </div>

      {/* Right: live clock */}
      <div className="flex items-center gap-2">
        <Clock className="h-3 w-3 text-gray-400" />
        <span className="font-mono tabular-nums text-gray-600">
          {clock.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })} ·{' '}
          {clock.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
        </span>
      </div>
    </footer>
  );

  // ============================================================
  // Render
  // ============================================================

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Desktop sidebar */}
      <aside
        className={`hidden lg:flex relative flex-col bg-white border-r border-gray-200 transition-all duration-300 ${
          collapsed ? 'w-16' : 'w-64'
        }`}
      >
        {collapseButton}
        {renderNavContent()}
      </aside>

      {/* Mobile sidebar drawer */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm animate-fade-in"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="relative z-10 flex w-64 flex-col bg-white animate-slide-in-left">
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute right-2 top-3 rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 z-10"
            >
              <X className="h-5 w-5" />
            </button>
            {renderNavContent(true)}
          </aside>
        </div>
      )}

      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {desktopHeader}
        {mobileHeader}
        <main className="flex-1 overflow-y-auto">{children}</main>
        {statusFooter}
      </div>

      {/* Document preview modal */}
      <DocumentPreviewModal
        open={previewType !== null}
        type={previewType}
        repair={previewRepair}
        onClose={() => setPreviewType(null)}
      />
    </div>
  );
}

// ============================================================
// Preview anchor exports — for future print preview popups
// ============================================================

export const PREVIEW_ANCHORS = {
  invoice: { key: 'invoice-preview', icon: <Receipt className="h-4 w-4" />, label: 'Invoice Preview' },
  receipt: { key: 'receipt-preview', icon: <FileText className="h-4 w-4" />, label: 'Receipt Preview' },
  barcode: { key: 'barcode-preview', icon: <ScanLine className="h-4 w-4" />, label: 'Barcode/Label Preview' },
} as const;
