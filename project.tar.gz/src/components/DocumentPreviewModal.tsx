import { type ReactNode } from 'react';
import { X, Printer, FileText, Receipt, ScanLine, ShieldCheck } from 'lucide-react';
import type { RepairRecord } from '../types';

// ============================================================
// Document preview types
// ============================================================

export type PreviewType = 'invoice' | 'receipt' | 'barcode';

interface DocumentPreviewModalProps {
  open: boolean;
  type: PreviewType | null;
  repair: RepairRecord | null;
  onClose: () => void;
}

// ============================================================
// Company constants (from ui_components.py)
// ============================================================

const COMPANY = {
  name: 'CyGnuS SARL',
  address: 'Rue 920 George Matta Sideway, Dekwaneh, Al Metn, Lebanon.',
  phone: '+9611688433',
  mof: '#3929987-601',
};

const VAT_RATE = 0.11; // 11% VAT

// ============================================================
// Barcode generator (Code93-style visual simulation)
// ============================================================

function BarcodeStrips({ value }: { value: string }) {
  // Generate deterministic bar patterns from the string
  const bars: ReactNode[] = [];
  let x = 0;
  for (let i = 0; i < value.length; i++) {
    const charCode = value.charCodeAt(i);
    // Each character produces 3 bars + 3 spaces of varying width
    const pattern = [
      (charCode % 3) + 1,
      ((charCode >> 2) % 3) + 1,
      ((charCode >> 4) % 3) + 1,
    ];
    pattern.forEach((width, j) => {
      const isBar = j % 2 === 0;
      bars.push(
        <rect
          key={`${i}-${j}`}
          x={x}
          y={0}
          width={width}
          height={50}
          fill={isBar ? '#000' : '#fff'}
        />
      );
      x += width;
    });
  }
  // Add quiet zones
  const totalWidth = x + 4;
  return (
    <svg viewBox={`0 0 ${totalWidth} 50`} className="w-full h-12" preserveAspectRatio="none">
      <rect x={0} y={0} width={totalWidth} height={50} fill="#fff" />
      {bars}
    </svg>
  );
}

// ============================================================
// Main modal component
// ============================================================

export function DocumentPreviewModal({ open, type, repair, onClose }: DocumentPreviewModalProps) {
  if (!open || !type) return null;

  const handlePrint = () => {
    window.print();
  };

  const titles: Record<PreviewType, { title: string; icon: ReactNode }> = {
    invoice: { title: 'Commercial Invoice Preview', icon: <FileText className="h-5 w-5" /> },
    receipt: { title: 'Thermal Deposit Receipt Preview', icon: <Receipt className="h-5 w-5" /> },
    barcode: { title: 'Barcode Asset Label Preview', icon: <ScanLine className="h-5 w-5" /> },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-gray-900/50 backdrop-blur-sm animate-fade-in print:bg-white print:block print:static print:overflow-visible">
      <div className="relative z-10 w-full my-4 print:my-0">
        {/* Modal toolbar — hidden in print */}
        <div className="no-print mx-auto max-w-4xl mb-3 flex items-center justify-between rounded-xl bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-brand-600">{titles[type].icon}</span>
            <h2 className="text-base font-semibold text-gray-900">{titles[type].title}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-brand-700"
            >
              <Printer className="h-4 w-4" />
              Print Document
            </button>
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Document area */}
        <div className="mx-auto max-w-4xl print:max-w-full print:w-full">
          {type === 'invoice' && <InvoiceDocument repair={repair} />}
          {type === 'receipt' && <ReceiptDocument repair={repair} />}
          {type === 'barcode' && <BarcodeDocument repair={repair} />}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// A. Commercial Invoice (A4)
// ============================================================

function InvoiceDocument({ repair }: { repair: RepairRecord | null }) {
  const docNumber = repair?.repair_id || 'REP-0001';
  const date = new Date().toLocaleDateString('en-GB');
  const customer = repair?.customer_name || 'Walk-in Customer';
  const phone = repair?.phone || '—';
  const device = `${repair?.brand || ''} ${repair?.model || ''}`.trim() || '—';
  const serial = repair?.serial || '—';
  const problem = repair?.problem || 'Diagnostic & Repair';
  const cost = repair?.price || 0;
  const subtotal = cost;
  const vat = subtotal * VAT_RATE;
  const grandTotal = subtotal + vat;

  return (
    <div className="document-invoice mx-auto bg-white p-10 shadow-xl print:shadow-none" style={{ maxWidth: '210mm', minHeight: '297mm' }}>
      {/* Header */}
      <div className="flex items-start justify-between border-b-2 border-gray-800 pb-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-brand-600 text-white">
              <ShieldCheck className="h-7 w-7" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">{COMPANY.name}</h1>
          </div>
          <p className="text-sm text-gray-600 max-w-xs">{COMPANY.address}</p>
          <p className="text-sm text-gray-600 mt-1">Tel: {COMPANY.phone}</p>
          <p className="text-sm text-gray-600">MOF: {COMPANY.mof}</p>
        </div>
        <div className="text-right">
          <h2 className="text-2xl font-bold text-gray-900">INVOICE</h2>
          <p className="text-sm text-gray-500 mt-1">Document #: {docNumber}</p>
          <p className="text-sm text-gray-500">Date: {date}</p>
        </div>
      </div>

      {/* Customer metadata */}
      <div className="mt-6 grid grid-cols-2 gap-6">
        <div>
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Bill To</h3>
          <p className="text-sm font-medium text-gray-900">{customer}</p>
          <p className="text-sm text-gray-600">{phone}</p>
        </div>
        <div>
          <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Device</h3>
          <p className="text-sm font-medium text-gray-900">{device}</p>
          <p className="text-sm text-gray-600">Serial: {serial}</p>
        </div>
      </div>

      {/* Items table */}
      <table className="mt-6 w-full border-collapse">
        <thead>
          <tr className="border-b-2 border-gray-300">
            <th className="py-2 px-3 text-left text-xs font-bold text-gray-600 uppercase">Item Description</th>
            <th className="py-2 px-3 text-left text-xs font-bold text-gray-600 uppercase">Brand</th>
            <th className="py-2 px-3 text-left text-xs font-bold text-gray-600 uppercase">Model</th>
            <th className="py-2 px-3 text-left text-xs font-bold text-gray-600 uppercase">Serial Number</th>
            <th className="py-2 px-3 text-left text-xs font-bold text-gray-600 uppercase">Work Performed</th>
            <th className="py-2 px-3 text-right text-xs font-bold text-gray-600 uppercase">Cost / Repair Fee</th>
          </tr>
        </thead>
        <tbody>
          <tr className="border-b border-gray-200">
            <td className="py-3 px-3 text-sm text-gray-700">{device} — Repair Service</td>
            <td className="py-3 px-3 text-sm text-gray-700">{repair?.brand || '—'}</td>
            <td className="py-3 px-3 text-sm text-gray-700">{repair?.model || '—'}</td>
            <td className="py-3 px-3 text-sm text-gray-700 font-mono">{serial}</td>
            <td className="py-3 px-3 text-sm text-gray-700">{problem}</td>
            <td className="py-3 px-3 text-sm text-gray-900 font-medium text-right">{cost.toLocaleString()} LBP</td>
          </tr>
        </tbody>
      </table>

      {/* Summary */}
      <div className="mt-6 flex justify-end">
        <div className="w-64 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Subtotal</span>
            <span className="font-medium text-gray-900">{subtotal.toLocaleString()} LBP</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">VAT (11%)</span>
            <span className="font-medium text-gray-900">{vat.toFixed(0).toLocaleString()} LBP</span>
          </div>
          <div className="flex justify-between border-t-2 border-gray-800 pt-2">
            <span className="font-bold text-gray-900">Grand Total</span>
            <span className="font-bold text-gray-900 text-lg">{grandTotal.toFixed(0).toLocaleString()} LBP</span>
          </div>
        </div>
      </div>

      {/* Signature */}
      <div className="mt-16 flex justify-between">
        <div>
          <p className="text-xs text-gray-400">Authorized Signature</p>
          <div className="mt-8 w-48 border-t border-gray-300" />
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-400">Date Issued</p>
          <p className="mt-8 text-sm text-gray-700">{date}</p>
        </div>
      </div>

      <p className="mt-8 text-center text-xs text-gray-400">
        Thank you for choosing {COMPANY.name}. This invoice was generated electronically.
      </p>
    </div>
  );
}

// ============================================================
// B. Thermal Deposit Receipt (80mm)
// ============================================================

function ReceiptDocument({ repair }: { repair: RepairRecord | null }) {
  const ticketId = repair?.repair_id || 'REP-0001';
  const date = new Date().toLocaleString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const phone = repair?.phone || '—';
  const device = `${repair?.brand || ''} ${repair?.model || ''}`.trim() || '—';
  const deposit = repair?.price || 0;

  return (
    <div className="document-receipt mx-auto bg-white p-4 shadow-xl print:shadow-none" style={{ width: '80mm' }}>
      {/* Shop header */}
      <div className="text-center border-b border-dashed border-gray-400 pb-3">
        <h1 className="text-lg font-bold text-gray-900">{COMPANY.name}</h1>
        <p className="text-[10px] text-gray-600 leading-tight mt-0.5">{COMPANY.address}</p>
        <p className="text-[10px] text-gray-600">Tel: {COMPANY.phone}</p>
        <p className="text-[10px] text-gray-600">MOF: {COMPANY.mof}</p>
      </div>

      {/* Title */}
      <div className="text-center py-2">
        <p className="text-xs font-bold text-gray-700 uppercase tracking-wider">Deposit Receipt</p>
      </div>

      <div className="border-t border-dashed border-gray-400" />

      {/* Ticket ID — large prominent */}
      <div className="text-center py-3">
        <p className="text-[10px] text-gray-500 uppercase">Ticket ID</p>
        <p className="text-2xl font-bold text-gray-900 font-mono tracking-wider">{ticketId}</p>
      </div>

      <div className="border-t border-dashed border-gray-400" />

      {/* Details */}
      <div className="py-2 space-y-1.5 text-xs">
        <div className="flex justify-between">
          <span className="text-gray-500">Date:</span>
          <span className="text-gray-900 font-medium">{date}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Customer Phone:</span>
          <span className="text-gray-900 font-medium">{phone}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Device:</span>
          <span className="text-gray-900 font-medium">{device}</span>
        </div>
      </div>

      <div className="border-t border-dashed border-gray-400" />

      {/* Deposit badge */}
      <div className="py-3 text-center">
        <p className="text-[10px] text-gray-500 uppercase mb-1">Deposit Amount Paid</p>
        <div className="inline-block rounded-lg bg-gray-900 px-6 py-2">
          <span className="text-xl font-bold text-white">{deposit.toLocaleString()} LBP</span>
        </div>
      </div>

      <div className="border-t border-dashed border-gray-400" />

      {/* Disclaimer */}
      <div className="py-3 text-center">
        <p className="text-xs font-semibold text-gray-700">
          Bring it when collecting your device after repair.
        </p>
      </div>

      <div className="border-t border-dashed border-gray-400" />

      <p className="text-center text-[9px] text-gray-400 mt-2">
        {COMPANY.name} · Printed on {date}
      </p>
    </div>
  );
}

// ============================================================
// C. Barcode Asset Sticker Label
// ============================================================

function BarcodeDocument({ repair }: { repair: RepairRecord | null }) {
  const repairId = repair?.repair_id || 'REP-1001';
  const customer = repair?.customer_name || 'John Doe';
  const phone = repair?.phone || '+961 01 234 567';
  const barcodeValue = repairId.replace(/-/g, '') + customer.replace(/\s/g, '').toUpperCase().slice(0, 4);

  return (
    <div className="document-barcode flex items-center justify-center py-8 print:py-0">
      <div className="bg-white border-2 border-gray-900 p-4 shadow-xl print:shadow-none" style={{ width: '89mm', height: '42mm' }}>
        <div className="flex h-full gap-3">
          {/* Left: barcode */}
          <div className="flex flex-col justify-between w-2/3">
            <div>
              <BarcodeStrips value={barcodeValue} />
              <p className="text-center text-[10px] font-mono text-gray-700 mt-1">{barcodeValue}</p>
            </div>
            <p className="text-center text-[8px] text-gray-500 mt-1">Code93 · {COMPANY.name}</p>
          </div>

          {/* Right: info */}
          <div className="flex flex-col justify-center w-1/3 border-l border-gray-300 pl-3">
            <div className="mb-1">
              <p className="text-[7px] text-gray-400 uppercase">Repair ID</p>
              <p className="text-sm font-bold text-gray-900 font-mono">{repairId}</p>
            </div>
            <div className="mb-1">
              <p className="text-[7px] text-gray-400 uppercase">Customer</p>
              <p className="text-[10px] font-medium text-gray-800 leading-tight">{customer}</p>
            </div>
            <div>
              <p className="text-[7px] text-gray-400 uppercase">Contact</p>
              <p className="text-[10px] font-medium text-gray-800">{phone}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
