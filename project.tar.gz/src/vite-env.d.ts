/// <reference types="vite/client" />


